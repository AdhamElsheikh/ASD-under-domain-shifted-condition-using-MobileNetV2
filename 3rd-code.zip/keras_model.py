#!/usr/bin/env python
# coding: utf-8

# ######################################################################<br>
# import python-library<br>
# ######################################################################<br>
# from import

# In[1]:


import keras.models
from keras import backend as K
from keras.layers import Input, Concatenate
from keras.applications.mobilenet_v2 import MobileNetV2
from keras.models import Model
from tensorflow.keras.optimizers import Adam


# ######################################################################<br>
# keras model<br>
# ######################################################################

# In[3]:





# In[1]:


def get_model(n_frames, n_mels, n_conditions, lr):
    """
    define the keras model
    the model based on MobileNetV2
    """

    sub_model = MobileNetV2(input_shape=(n_frames, n_mels, 3),
                            alpha=0.5, 
                            weights=None,
                            classes=n_conditions)
   
    x = Input(shape=(n_frames, n_mels, 1))
    h = x
    h = Concatenate()([h, h, h])
    h = sub_model(h)

    model = Model(x, h)

    model.compile(optimizer=keras.optimizers.Adam(lr=lr), 
                  loss='categorical_crossentropy', 
                  metrics=['accuracy'])

    return model


# #######################################################################

# In[3]:


def load_model(file_path):
    return keras.models.load_model(file_path, compile=False)


# In[4]:


def clear_session():
    K.clear_session()
    


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




