#!/usr/bin/env python
# coding: utf-8

# In[1]:


pip install wavio


# In[2]:


pip install sounddevice


# In[2]:


import glob
import argparse
import sys
import os
import itertools
import re
import numpy as np
import librosa
import librosa.core
import librosa.feature
import librosa.display
import yaml
import wave


# In[3]:



from scipy.io.wavfile import write
import wavio as wv
import os
import sounddevice as sd


# In[4]:


def file_load(wav_name, mono=False):
    """
    load .wav file.
    wav_name : str
        target .wav file
    mono : boolean
        When load a multi channels file and this param True, the returned data will be merged for mono data
    return : numpy.array( float )
    """
    try:
        return librosa.load(wav_name, sr=None, mono=mono)
    except:
        logger.error("file_broken or not exists!! : {}".format(wav_name))


# In[5]:


def pitch(data, sr):
    return librosa.effects.pitch_shift(data, sr=sr, n_steps = 3)


# In[6]:


import os
# assign directory
directory = 'A:\\bachelor3\\dev_data\\ToyTrain\\train'
 
# iterate over files in
# that directory
for filename in os.listdir(directory):
    f = os.path.join(directory, filename)
    x,samplerate=librosa.load(f,mono=False)
    newsample = pitch(x,samplerate)
    wv.write(os.path.join("A:\\toytrain\\train\\"+filename+".wav")
         ,newsample, samplerate, sampwidth=1) 
print("finished")


# In[7]:


import os
# assign directory
directory = 'A:\\bachelor3\\dev_data\\valve\\train'
 
# iterate over files in
# that directory
for filename in os.listdir(directory):
    f = os.path.join(directory, filename)
    x,samplerate=librosa.load(f,mono=False)
    newsample = pitch(x,samplerate)
    wv.write(os.path.join("A:\\valve\\train\\"+filename+".wav")
         ,newsample, samplerate, sampwidth=1) 
print("finished")


# In[8]:


import os
# assign directory
directory = 'A:\\bachelor3\\dev_data\\pump\\train'
 
# iterate over files in
# that directory
for filename in os.listdir(directory):
    f = os.path.join(directory, filename)
    x,samplerate=librosa.load(f,mono=False)
    newsample = pitch(x,samplerate)
    wv.write(os.path.join("A:\\pump\\train\\"+filename+".wav")
         ,newsample, samplerate, sampwidth=1) 
print("finished")


# In[9]:


import os
# assign directory
directory = 'A:\\bachelor3\\dev_data\\slider\\train'
 
# iterate over files in
# that directory
for filename in os.listdir(directory):
    f = os.path.join(directory, filename)
    x,samplerate=librosa.load(f,mono=False)
    newsample = pitch(x,samplerate)
    wv.write(os.path.join("A:\\slider\\train\\"+filename+".wav")
         ,newsample, samplerate, sampwidth=1) 
print("finished")


# In[10]:


import os
# assign directory
directory = 'A:\\bachelor3\\dev_data\\gearbox\\train'
 
# iterate over files in
# that directory
for filename in os.listdir(directory):
    f = os.path.join(directory, filename)
    x,samplerate=librosa.load(f,mono=False)
    newsample = pitch(x,samplerate)
    wv.write(os.path.join("A:\\gearbox\\train\\"+filename+".wav")
         ,newsample, samplerate, sampwidth=1) 
print("finished")


# In[ ]:


import os
# assign directory
directory = 'A:\\bachelor3\\dev_data\\fan\\train'
 
# iterate over files in
# that directory
for filename in os.listdir(directory):
    f = os.path.join(directory, filename)
    x,samplerate=librosa.load(f,mono=False)
    newsample = pitch(x,samplerate)
    wv.write(os.path.join("A:\\fan\\train\\"+filename+".wav")
         ,newsample, samplerate, sampwidth=1) 
print("finished")


# In[ ]:




